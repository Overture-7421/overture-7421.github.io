#include "header.h"

void func() {
  c_doThing();
}
