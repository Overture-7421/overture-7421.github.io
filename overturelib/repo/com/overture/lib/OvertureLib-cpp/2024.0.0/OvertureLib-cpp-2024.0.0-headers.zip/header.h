#pragma once

void c_doThing() {

}