// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#pragma once

#include <vector>
#include <algorithm>
#include <wpi/array.h>
#include <frc/geometry/Pose2d.h>
#include <units/length.h>
#include <units/time.h>

#include "OvertureLib/Subsystems/Swerve/SwerveChassis/SwerveChassis.h"

struct VisionEstimate {
	std::string cameraName;
	frc::Pose2d pose;
	units::second_t timestamp;
	int tagCount;
	units::meter_t avgDist;
	wpi::array<double, 3> stdDevs { 0.0, 0.0, 0.0 };
};

class VisionManager {
public:
	static VisionManager& GetInstance();

	void SetChassis(SwerveChassis *chassis);
	void SubmitEstimate(VisionEstimate estimate);
	void ProcessEstimates();

	void SetIQRMultiplier(double multiplier);

private:
	VisionManager() = default;

	std::vector<VisionEstimate> FilterByIQR(
			const std::vector<VisionEstimate> &estimates);

	SwerveChassis *chassis = nullptr;
	std::vector<VisionEstimate> pendingEstimates;
	double iqrMultiplier = 1.5;
};
