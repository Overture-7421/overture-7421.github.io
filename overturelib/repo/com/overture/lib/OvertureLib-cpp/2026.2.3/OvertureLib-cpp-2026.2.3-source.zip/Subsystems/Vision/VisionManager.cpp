// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#include "OvertureLib/Subsystems/Vision/VisionManager.h"
#include "OvertureLib/Utils/Logging/Logging.h"

#include <frc/Timer.h>
#include <numeric>

VisionManager& VisionManager::GetInstance() {
	static VisionManager instance;
	return instance;
}

void VisionManager::SetChassis(SwerveChassis *chassis) {
	this->chassis = chassis;
}

void VisionManager::SubmitEstimate(VisionEstimate estimate) {
	pendingEstimates.push_back(std::move(estimate));
}

void VisionManager::ProcessEstimates() {
	if (!chassis || pendingEstimates.empty()) {
		pendingEstimates.clear();
		return;
	}

	std::vector < VisionEstimate > accepted;

	if (pendingEstimates.size() >= 3) {
		// Enough data for IQR filtering
		accepted = FilterByIQR(pendingEstimates);
	} else if (pendingEstimates.size() == 2) {
		// Two cameras: accept both if they agree, reject both if they don't
		units::meter_t dist = pendingEstimates[0].pose.Translation().Distance(
				pendingEstimates[1].pose.Translation());
		if (dist < 1.0_m) {
			accepted = pendingEstimates;
		}
	} else {
		// Single camera: trust stdDevs to handle confidence
		accepted = pendingEstimates;
	}

	for (const auto &est : accepted) {
		chassis->addVisionMeasurement(est.pose, est.timestamp, est.stdDevs);
		Logging::LogPose2d("/Swerve/Vision/" + est.cameraName, est.pose,
				frc::Timer::GetFPGATimestamp() - est.timestamp);
	}

	pendingEstimates.clear();
}

void VisionManager::SetIQRMultiplier(double multiplier) {
	this->iqrMultiplier = multiplier;
}

std::vector<VisionEstimate> VisionManager::FilterByIQR(
		const std::vector<VisionEstimate> &estimates) {

	// Extract X and Y values
	std::vector<double> xVals, yVals;
	for (const auto &est : estimates) {
		xVals.push_back(est.pose.X().value());
		yVals.push_back(est.pose.Y().value());
	}

	std::vector<double> sortedX = xVals;
	std::vector<double> sortedY = yVals;
	std::sort(sortedX.begin(), sortedX.end());
	std::sort(sortedY.begin(), sortedY.end());

	size_t n = sortedX.size();
	double q1X = sortedX[n / 4];
	double q3X = sortedX[3 * n / 4];
	double iqrX = q3X - q1X;

	double q1Y = sortedY[n / 4];
	double q3Y = sortedY[3 * n / 4];
	double iqrY = q3Y - q1Y;

	// Minimum IQR to avoid rejecting everything when cameras tightly agree
	double minIQR = 0.3;
	iqrX = std::max(iqrX, minIQR);
	iqrY = std::max(iqrY, minIQR);

	double lowerX = q1X - iqrMultiplier * iqrX;
	double upperX = q3X + iqrMultiplier * iqrX;
	double lowerY = q1Y - iqrMultiplier * iqrY;
	double upperY = q3Y + iqrMultiplier * iqrY;

	std::vector < VisionEstimate > filtered;
	for (size_t i = 0; i < estimates.size(); i++) {
		if (xVals[i] >= lowerX && xVals[i] <= upperX && yVals[i] >= lowerY
				&& yVals[i] <= upperY) {
			filtered.push_back(estimates[i]);
		}
	}

	return filtered;
}
